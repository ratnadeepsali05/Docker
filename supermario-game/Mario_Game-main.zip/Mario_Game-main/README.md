# Mario_Game
A Mario game made with Javascript and Kaboom.js!

**To play the game, do the following:** <br> 
* Download the files to your computer <br> 
* Using visual studio code, copy the path of file "index.html" using right click <br> 
* Copy the link to Google Chrome in order to play <br> 
* Enjoy the game! <br> 

**Screenshots:** <br> 
<img width="756" alt="Screen Shot 2023-09-21 at 1 40 35 AM" src="https://github.com/Max00358/Mario_Game/assets/125518862/f365987c-a6d2-4599-9ab2-fc81fafe62c5"> <br> 
<img width="757" alt="Screen Shot 2023-09-21 at 1 40 56 AM" src="https://github.com/Max00358/Mario_Game/assets/125518862/287de1c5-833e-4ca1-b104-46d14cfe8296"> <br> 
